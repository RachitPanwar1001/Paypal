import React from "react";
import { View, Text, StyleSheet, Image } from "react-native";

function Header() {
	return (
		<View style={styles.header}>
			<Text style={styles.headerText}>PocketPal</Text>
			<Image source={require("../assets/logo.png")} style={styles.logo} />
		</View>
	);
}
const styles = StyleSheet.create({
	header: {
		padding: 16,
		borderBottomWidth: 1,
		borderBottomColor: "#3B9188",
		alignItems: "center",
	},
	headerText: {
		fontSize: 24,
		fontWeight: "bold",
		color: "#00A9FF",
	},
	logo: {
		width: 50,
		height: 50,
		marginTop: 8,
	},
});

export default Header;
