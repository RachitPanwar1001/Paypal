import AsyncStorage from "@react-native-async-storage/async-storage";
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore/lite";

const firebaseConfig = {
	apiKey: "AIzaSyC9ZHpArbP__nNczZysq1BXUcig67XAmaY",
	authDomain: "pocketpal2-c530b.firebaseapp.com",
	projectId: "pocketpal2-c530b",
	storageBucket: "pocketpal2-c530b.appspot.com",
	messagingSenderId: "521888453381",
	appId: "1:521888453381:web:e1e12797c4283c67f0dd6c"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const username = "Moulik";

export { db, username };
