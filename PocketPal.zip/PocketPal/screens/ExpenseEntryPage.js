import React, { useState } from "react";
import { View, Text, TextInput, Button, TouchableOpacity, StyleSheet } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import SafeAreaView from "react-native-safe-area-view";
import FontAwesome5 from "@expo/vector-icons/FontAwesome5";
import { db, username } from "../components/firestore";
import { collection, addDoc } from "firebase/firestore/lite";

const ExpenseEntryScreen = ({ navigation }) => {
	const [name, setName] = useState("");
	const [amount, setAmount] = useState("");
	const [category, setCategory] = useState("");
	const [description, setDescription] = useState("");
	const [splitEqually, setSplitEqually] = useState(true);

	const handleAddExpense = () => {
		// Handle logic to add the expense to the database (Firebase or SQLite)
		// You can access the splitEqually state to determine how to split the expense
		// You can also include logic for splitting expenses among friends
		// Provide feedback to the user, e.g., show a success message or navigate to another screen
		// username.then((username) => 
		addDoc(collection(db, "expense"), { rname: username, name: name, amount: amount, category: category, description: description })
		// );
		navigation.reset({
			index: 0,
			routes: [{ name: "Tab" }],
		});
	};

	return (
		<SafeAreaProvider>
			<SafeAreaView style={styles.container} forceInset={{ top: "always" }}>
				<View style={styles.content}>
					<Text style={styles.header}>Expense Entry</Text>

					<View style={styles.inputContainer}>
						<Text style={styles.label}>Name</Text>
						<TextInput style={styles.input} placeholder="Enter name" value={name} onChangeText={(text) => setName(text)} />
					</View>

					<View style={styles.inputContainer}>
						<Text style={styles.label}>Amount</Text>
						<TextInput style={styles.input} placeholder="Enter amount" keyboardType="numeric" value={amount} onChangeText={(text) => setAmount(text)} />
					</View>

					<View style={styles.inputContainer}>
						<Text style={styles.label}>Category</Text>
						<TextInput style={styles.input} placeholder="Enter category" value={category} onChangeText={(text) => setCategory(text)} />
					</View>

					<View style={styles.inputContainer}>
						<Text style={styles.label}>Description</Text>
						<TextInput style={styles.input} placeholder="Enter description" value={description} onChangeText={(text) => setDescription(text)} />
					</View>

					{/* <View style={styles.splitContainer}>
						<Text style={styles.label}>Split Among Friends</Text>
						<View style={styles.splitOptions}>
							<TouchableOpacity style={[styles.splitOption, splitEqually && styles.selectedOption]} onPress={() => setSplitEqually(true)}>
								<FontAwesome5 name="equals" size={24} color="#3B9188" />
								<Text style={styles.splitOptionText}>Equally</Text>
							</TouchableOpacity>
							<TouchableOpacity style={[styles.splitOption, !splitEqually && styles.selectedOption]} onPress={() => setSplitEqually(false)}>
								<FontAwesome5 name="sliders-h" size={24} color="#3B9188" />
								<Text style={styles.splitOptionText}>Custom</Text>
							</TouchableOpacity>
						</View>
					</View> */}

					<View style={styles.actionButtonsContainer}>
						<TouchableOpacity style={[styles.actionButton, { backgroundColor: "#00A9FF" }]} onPress={handleAddExpense}>
							<Text style={styles.buttonText}>Add Expense</Text>
						</TouchableOpacity>
					</View>
				</View>
			</SafeAreaView>
		</SafeAreaProvider>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#DFF5F2",
	},
	content: {
		flex: 1,
		padding: 16,
	},
	header: {
		fontSize: 24,
		fontWeight: "bold",
		marginBottom: 24,
		color: "#00A9FF",
	},
	inputContainer: {
		marginBottom: 16,
	},
	label: {
		fontSize: 16,
		marginBottom: 8,
		color: "#3B9188",
	},
	input: {
		height: 40,
		borderColor: "#00A9FF",
		borderWidth: 1,
		borderRadius: 8,
		paddingHorizontal: 8,
	},
	splitContainer: {
		marginBottom: 16,
	},
	splitOptions: {
		flexDirection: "row",
		justifyContent: "space-around",
	},
	splitOption: {
		flexDirection: "row",
		alignItems: "center",
		padding: 8,
		borderRadius: 8,
		borderWidth: 1,
		borderColor: "#3B9188",
	},
	selectedOption: {
		backgroundColor: "#83d9ed",
	},
	splitOptionText: {
		marginLeft: 8,
		color: "#3B9188",
	},
	actionButtonsContainer: {
		flexDirection: "row",
		justifyContent: "space-between",
	},
	actionButton: {
		flex: 1,
		height: 50,
		alignItems: "center",
		justifyContent: "center",
		borderRadius: 8,
		marginRight: 10,
	},
	buttonText: {
		color: "#fff",
		fontSize: 16,
		fontWeight: "bold",
	},
});

export default ExpenseEntryScreen;
