import { FontAwesome5 } from "@expo/vector-icons";
import React, { useState, useEffect } from "react";
import { StyleSheet, View, Text, FlatList, Button, TouchableOpacity } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import SafeAreaView from "react-native-safe-area-view";
import Header from "../components/Header";

const NotificationHistory = ({ navigation }) => {
	const [notifications, setNotifications] = useState([]);

	useEffect(() => {
		// Fetch notifications from the database (Firebase or SQLite)
		// For now, using dummy data as placeholder
		const dummyNotifications = [
			{ id: "1", title: "Weekly Reminder", message: "Don't forget to settle your expenses!", timestamp: "2023-12-07" },
			{ id: "2", title: "Weekly Reminder", message: "Don't forget to settle your expenses!", timestamp: "2023-11-30" },
		];
		setNotifications(dummyNotifications);
	}, []);

	return (
		<SafeAreaProvider>
			<SafeAreaView style={styles.container} forceInset={{ top: "always" }}>
				<Header />
				<View style={styles.notificationCenter}>
					<View style={styles.title}>
						<Text style={styles.sectionTitle}>Notification Center</Text>
						<TouchableOpacity onPress={() => navigation.navigate("NotifSettings")}>
							<FontAwesome5 name="cog" size={24} color="#00A9FF" />
						</TouchableOpacity>
					</View>
					<FlatList
						data={notifications}
						keyExtractor={(item) => item.id}
						renderItem={({ item }) => (
							<View style={styles.notificationItem}>
								<Text style={styles.notificationTitle}>{item.title}</Text>
								<Text style={styles.notificationMessage}>{item.message}</Text>
								<Text style={styles.notificationTimestamp}>{item.timestamp}</Text>
							</View>
						)}
					/>
				</View>
			</SafeAreaView>
		</SafeAreaProvider>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#DFF5F2",
	},
	notificationCenter: {
		flex: 1,
		padding: 20,
	},
	title: {
		flexDirection: "row",
		justifyContent: "space-between",
		alignItems: "center",
	},
	sectionTitle: {
		fontSize: 20,
		color: "#3B9188",
		marginBottom: 10,
	},
	notificationItem: {
		backgroundColor: "#FFF",
		borderRadius: 8,
		padding: 15,
		marginBottom: 10,
	},
	notificationTitle: {
		fontSize: 18,
		fontWeight: "bold",
		marginBottom: 5,
	},
	notificationMessage: {
		fontSize: 16,
		marginBottom: 5,
	},
	notificationTimestamp: {
		fontSize: 12,
		color: "#888",
	},
});

export default NotificationHistory;
