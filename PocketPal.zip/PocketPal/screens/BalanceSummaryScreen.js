import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import SafeAreaView from "react-native-safe-area-view";
import Header from "../components/Header";
import { db, username } from "../components/firestore";
import { collection, getDocs } from "firebase/firestore/lite";

async function docs() {
	const result = await getDocs(collection(db, "expense"));
	return result;
}

const BalanceSummaryScreen = () => {
	const [balances, setBalances] = useState([
		{ friend: "John Doe", balance: -25.5 },
		{ friend: "Jane Smith", balance: 10.75 },
	]);

	const [data, setData] = useState([]);
	const [isLoading, setLoading] = useState(true);

	useEffect(() => {
		if (isLoading)
			docs().then((data) => {
				setData(data);
				setLoading(false);
			});

		// username.then((username) => {
			let result = {};
			let list = [];
			data.forEach((doc) => {
				const amt = Number(doc.data().amount);
				if (doc.data().name == username) {
					let person = doc.data().rname;
					if (result[person] != undefined) result[person] += amt;
					else {
						result[person] = amt;
						list = [...list, { name: person }];
					}
				} else if (doc.data().rname == username) {
					let person = doc.data().name;
					if (result[person] != undefined) result[person] -= amt;
					else {
						result[person] = -amt;
						list = [...list, { name: person }];
					}
				}
			});

			for (let index = 0; index < list.length; index++) {
				list[index] = { friend: list[index].name, balance: result[list[index].name] };
			}
			setBalances(list);
		// });
	}, [data]);

	return (
		<SafeAreaProvider>
			<SafeAreaView style={styles.container} forceInset={{ top: "always" }}>
				<Header />

				<View style={styles.balanceContainer}>
					<Text style={styles.sectionHeader}>Balance Summary</Text>
					{balances.map((entry, index) => (
						<View key={index} style={styles.balanceEntry}>
							<Text style={styles.friendText}>{entry.friend}</Text>
							<Text style={entry.balance < 0 ? styles.negativeBalance : styles.positiveBalance}>{entry.balance.toFixed(2)}</Text>
						</View>
					))}
				</View>

				<View style={styles.descriptionContainer}>
					<Text style={styles.sectionHeader}>How It Works</Text>
					<Text style={styles.descriptionText}>PocketPal helps you keep track of shared expenses with friends. See at a glance who owes and is owed.</Text>
				</View>
			</SafeAreaView>
		</SafeAreaProvider>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#DFF5F2",
	},
	balanceContainer: {
		padding: 16,
	},
	sectionHeader: {
		fontSize: 18,
		fontWeight: "bold",
		color: "#00A9FF",
		marginBottom: 12,
	},
	balanceEntry: {
		flexDirection: "row",
		justifyContent: "space-between",
		marginBottom: 8,
	},
	friendText: {
		fontSize: 16,
		color: "#3B9188",
	},
	positiveBalance: {
		fontSize: 16,
		color: "#3B9188",
	},
	negativeBalance: {
		fontSize: 16,
		color: "#FF0000",
	},
	descriptionContainer: {
		padding: 16,
		marginTop: 16,
		backgroundColor: "#FFFFFF",
		borderRadius: 8,
	},
	descriptionText: {
		fontSize: 16,
		color: "#3B9188",
	},
});

export default BalanceSummaryScreen;
