import React, { useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { View, Image, Text, TextInput, TouchableOpacity, StyleSheet } from "react-native";
import { NavigationActions } from '@react-navigation/native-stack';
import { SafeAreaProvider } from "react-native-safe-area-context";
import SafeAreaView from "react-native-safe-area-view";

const RegisterScreen = ({ navigation }) => {
	const [username, setUsername] = useState("");
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");

	const handleRegister = () => {
		try {
			AsyncStorage.setItem("username", username);
			navigation.reset({
				index: 0,
				routes: [{ name: 'Tab' }],
			  });
		} catch (error) {
			console.log(error);
		}
	};

	const navigateToLogin = () => {
		navigation.navigate("Login");
	};

	return (
		<SafeAreaProvider>
			<SafeAreaView style={styles.container} forceInset={{ top: "always" }}>
				<View style={styles.header}>
					<Text style={styles.logo}>PocketPal</Text>
					<Image source={require("../assets/logo.png")} style={styles.image} />
				</View>
				<View style={styles.form}>
					<TextInput style={styles.input} placeholder="Username" autoCapitalize="none" value={username} onChangeText={(text) => setUsername(text)} />
					<TextInput style={styles.input} placeholder="Email" keyboardType="email-address" autoCapitalize="none" value={email} onChangeText={(text) => setEmail(text)} />
					<TextInput style={styles.input} placeholder="Password" secureTextEntry value={password} onChangeText={(text) => setPassword(text)} />
					<TouchableOpacity style={styles.button} onPress={handleRegister}>
						<Text style={styles.buttonText}>Register</Text>
					</TouchableOpacity>
					<TouchableOpacity style={styles.registerLink} onPress={navigateToLogin}>
						<Text style={styles.registerText}>Already have an account? Login here</Text>
					</TouchableOpacity>
				</View>
			</SafeAreaView>
		</SafeAreaProvider>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#DFF5F2",
		alignItems: "center",
	},
	header: {
		flex: 1,
		justifyContent: "center",
		alignItems: "center",
	},
	logo: {
		fontSize: 32,
		color: "#00A9FF",
	},
	image: {
		width: 50,
		height: 50,
		marginTop: 20,
	},
	form: {
		flex: 2,
		width: "80%",
		alignItems: "center",
	},
	input: {
		height: 40,
		width: "100%",
		borderColor: "#3B9188",
		borderBottomWidth: 2,
		marginBottom: 20,
		paddingHorizontal: 10,
	},
	button: {
		backgroundColor: "#3B9188",
		padding: 10,
		borderRadius: 5,
		width: "100%",
		alignItems: "center",
		marginVertical: 20,
	},
	buttonText: {
		color: "#fff",
		fontSize: 16,
	},
});

export default RegisterScreen;
