// Import necessary components and libraries
import React, { useState } from "react";
import { View, Text, Switch, TouchableOpacity, StyleSheet } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import SafeAreaView from "react-native-safe-area-view";

// Define the NotificationSettings component
const NotificationSettings = () => {
	const handleLogout = () => {
		// Implement your logout logic here
		// For example, navigate to the login screen or call a logout API
	};
	// State to manage notification preferences
	const [weeklyReminders, setWeeklyReminders] = useState(false);
	const [pendingPaymentsAlerts, setPendingPaymentsAlerts] = useState(false);

	return (
		<SafeAreaProvider>
			<SafeAreaView style={styles.container} forceInset={{ top: "always" }}>
				<View>
					<View style={styles.header}>
						<Text style={styles.headerText}>Notification Settings</Text>
					</View>
					<View style={styles.notificationOption}>
						<Text style={styles.optionText}>Weekly Reminders</Text>
						<Switch value={weeklyReminders} onValueChange={() => setWeeklyReminders(!weeklyReminders)} />
					</View>
					<View style={styles.notificationOption}>
						<Text style={styles.optionText}>Pending Payments Alerts</Text>
						<Switch value={pendingPaymentsAlerts} onValueChange={() => setPendingPaymentsAlerts(!pendingPaymentsAlerts)} />
					</View>
				</View>

				<TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
					<Text style={styles.logoutText}>Logout</Text>
				</TouchableOpacity>
			</SafeAreaView>
		</SafeAreaProvider>
	);
};

// Define styles
const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#DFF5F2",
		padding: 20,
		justifyContent: "space-between",
	},
	header: {
		paddingVertical: 20,
		borderBottomWidth: 1,
		borderBottomColor: "#3B9188",
	},
	headerText: {
		fontSize: 24,
		color: "#00A9FF",
	},
	notificationOption: {
		flexDirection: "row",
		justifyContent: "space-between",
		alignItems: "center",
		paddingVertical: 15,
		borderBottomWidth: 1,
		borderBottomColor: "#3B9188",
	},
	optionText: {
		fontSize: 18,
		color: "#3B9188",
	},
	logoutButton: {
		backgroundColor: "#3B9188",
		paddingVertical: 12,
		paddingHorizontal: 24,
		borderRadius: 8,
		marginTop: 20,
	},
	logoutText: {
		color: "white",
		fontSize: 16,
		fontWeight: "bold",
		textAlign: "center",
	},
});

export default NotificationSettings;
