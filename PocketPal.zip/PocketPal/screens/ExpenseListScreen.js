import React, { useEffect, useState } from "react";
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-view";
import SafeAreaView from "react-native-safe-area-view";
import { Ionicons } from "@expo/vector-icons";
import Header from "../components/Header";
import { db, username } from "../components/firestore";
import { collection, deleteDoc, doc, getDocs } from "firebase/firestore/lite";

async function docs() {
	const result = await getDocs(collection(db, "expense"));
	return result;
}

const ExpenseListScreen = () => {
	const dummyExpenses = [
		{ id: "1", title: "Dinner", amount: 25.5 },
		{ id: "2", title: "Groceries", amount: 40.0 },
	];

	const [data, setData] = useState([]);
	const [expenses, setExpenses] = useState(dummyExpenses);
	const [isLoading, setLoading] = useState(true);

	useEffect(() => {
		if (isLoading)
			docs().then((data) => {
				setData(data);
				setLoading(false);
			});

		// username.then((username) => {
			let result = [];
			data.forEach((doc) => {
				if (doc.data().name === username || doc.data().rname === username) result = [...result, { id: doc.id, title: doc.data().description, amount: Number(doc.data().amount) }];
			});
			setExpenses(result);
		// });
	}, [data]);

	const renderExpenseItem = ({ item }) => (
		<View style={styles.expenseItem}>
			<Text>{item.title}</Text>
			<View style={styles.expenseItemRight}>
				<Text>₹{item.amount.toFixed(2)}</Text>
				<TouchableOpacity onPress={() => handleDeleteExpense(item.id)}>
					<Ionicons name="trash" size={24} color="#3B9188" />
				</TouchableOpacity>
			</View>
		</View>
	);

	const handleEditExpense = (expenseId) => {
		console.log(`Edit expense with ID: ${expenseId}`);
	};

	const handleDeleteExpense = (expenseId) => {
		console.log(`Delete expense with ID: ${expenseId}`);
		const res = deleteDoc(doc(collection(db, "expense"), expenseId));
		setExpenses(expenses.filter((doc) => doc.id != expenseId));
	};

	return (
		<SafeAreaProvider>
			<SafeAreaView style={styles.container} forceInset={{ top: "always" }}>
				<Header />
				<View style={styles.header}>
					<Text style={styles.headerText}>Expense History</Text>
				</View>
				<FlatList data={expenses} keyExtractor={(item) => item.id} renderItem={renderExpenseItem} />
			</SafeAreaView>
		</SafeAreaProvider>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#DFF5F2",
	},
	header: {
		backgroundColor: "#00A9FF",
		padding: 20,
		alignItems: "center",
	},
	headerText: {
		color: "white",
		fontSize: 18,
		fontWeight: "bold",
	},
	expenseItem: {
		flexDirection: "row",
		justifyContent: "space-between",
		alignItems: "center",
		padding: 10,
		borderBottomWidth: 1,
		borderBottomColor: "#DFF5F2",
	},
	expenseItemRight: {
		width: "50%",
		flexDirection: "row",
		justifyContent: "space-between",
	},
});

export default ExpenseListScreen;
