import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import SafeAreaView from "react-native-safe-area-view";

const Dashboard = () => {
	// Placeholder data for the overview and recent transactions
	const overviewData = {
		balance: 1500,
		totalExpenses: 500,
		pendingPayments: 200,
	};

	const recentTransactions = [
		{ id: 1, description: "Groceries", amount: 50 },
		{ id: 2, description: "Dinner with friends", amount: 30 },
		{ id: 3, description: "Internet bill", amount: 80 },
		// Add more transactions as needed
	];

	return (
		<SafeAreaProvider>
			<SafeAreaView style={styles.container} forceInset={{ top: "always" }}>
				{/* Header */}
				<View style={styles.header}>
					<Text style={styles.headerText}>PocketPal</Text>
				</View>

				{/* Overview Section */}
				<View style={styles.overviewContainer}>
					<Text style={styles.sectionHeading}>Overview</Text>
					<View style={styles.overviewDetails}>
						<View style={styles.overviewItem}>
							<Text style={styles.itemLabel}>Balance</Text>
							<Text style={styles.itemValue}>${overviewData.balance}</Text>
						</View>
						<View style={styles.overviewItem}>
							<Text style={styles.itemLabel}>Total Expenses</Text>
							<Text style={styles.itemValue}>${overviewData.totalExpenses}</Text>
						</View>
						<View style={styles.overviewItem}>
							<Text style={styles.itemLabel}>Pending Payments</Text>
							<Text style={styles.itemValue}>${overviewData.pendingPayments}</Text>
						</View>
					</View>
				</View>

				{/* Recent Transactions Section */}
				<ScrollView style={styles.transactionsContainer}>
					<Text style={styles.sectionHeading}>Recent Transactions</Text>
					{recentTransactions.map((transaction) => (
						<View key={transaction.id} style={styles.transactionItem}>
							<Text style={styles.transactionDescription}>{transaction.description}</Text>
							<Text style={styles.transactionAmount}>-${transaction.amount}</Text>
						</View>
					))}
				</ScrollView>
			</SafeAreaView>
		</SafeAreaProvider>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#DFF5F2",
	},
	header: {
		backgroundColor: "#00A9FF",
		padding: 15,
		alignItems: "center",
	},
	headerText: {
		color: "#FFF",
		fontSize: 20,
		fontWeight: "bold",
	},
	overviewContainer: {
		padding: 20,
	},
	overviewDetails: {
		flexDirection: "row",
		justifyContent: "space-between",
	},
	overviewItem: {
		flex: 1,
		alignItems: "center",
		padding: 10,
		backgroundColor: "#FFF",
		borderRadius: 8,
		marginHorizontal: 5,
		justifyContent: "space-between",
	},
	itemLabel: {
		fontSize: 16,
		color: "#3B9188",
	},
	itemValue: {
		fontSize: 18,
		fontWeight: "bold",
	},
	transactionsContainer: {
		padding: 20,
	},
	sectionHeading: {
		color: "#3B9188",
		fontSize: 18,
		fontWeight: "bold",
		marginBottom: 10,
	},
	transactionItem: {
		flexDirection: "row",
		justifyContent: "space-between",
		alignItems: "center",
		backgroundColor: "#FFF",
		padding: 15,
		borderRadius: 8,
		marginBottom: 10,
	},
	transactionDescription: {
		fontSize: 16,
	},
	transactionAmount: {
		fontSize: 16,
		fontWeight: "bold",
		color: "#FF0000", // Expense amount color
	},
});

export default Dashboard;
