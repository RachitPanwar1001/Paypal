import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import SafeAreaView from "react-native-safe-area-view";
import Header from "../components/Header";
import { db, username } from "../components/firestore";
import { collection, getDocs } from "firebase/firestore/lite";
import { FontAwesome5 } from "@expo/vector-icons";

async function docs() {
	const result = await getDocs(collection(db, "expense"));
	return result;
}

const DashboardPage = ({ navigation }) => {
	const [data, setData] = useState([]);
	const [balance, setBalance] = useState(0);
	const [isLoading, setLoading] = useState(true);

	useEffect(() => {
		if (isLoading)
			docs().then((data) => {
				setData(data);
				setLoading(false);
			});
		// username.then((username) => {
			let total = 0;
			data.forEach((doc) => {
				const amt = Number(doc.data().amount);
				if (doc.data().name == username) {
					total += amt;
				} else if (doc.data().rname == username) {
					total -= amt;
				}
			});
			setBalance(total);
		// });
	}, [data]);
	return (
		<SafeAreaProvider>
			<SafeAreaView style={styles.container} forceInset={{ top: "always" }}>
				<Header />

				<View style={styles.balanceContainer}>
					<Text style={styles.balanceText}>Current Balance</Text>
					<Text style={styles.balanceAmount}>₹{balance.toFixed(2)}</Text>
				</View>

				<View style={styles.transactionsContainer} onStartShouldSetResponder={() => navigation.navigate("History")}>
					<Text style={styles.transactionsHeading}>
						Recent Transactions <FontAwesome5 name="arrow-right" color={"#3B9188"} size={15} />
					</Text>
				</View>

				<View style={styles.actionButtonsContainer}>
					<TouchableOpacity style={[styles.actionButton, { backgroundColor: "#00A9FF" }]} onPress={() => navigation.navigate("Entry")}>
						<Text style={styles.buttonText}>Add Expense</Text>
					</TouchableOpacity>
					<TouchableOpacity style={[styles.actionButton, { backgroundColor: "#3B9188" }]} onPress={() => navigation.navigate("Balance")}>
						<Text style={styles.buttonText}>See Balance</Text>
					</TouchableOpacity>
				</View>
			</SafeAreaView>
		</SafeAreaProvider>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#DFF5F2",
		padding: 16,
		paddingTop: 0,
	},
	logo: {
		width: 50,
		height: 50,
		marginTop: 8,
	},
	balanceContainer: {
		marginBottom: 20,
	},
	balanceText: {
		fontSize: 18,
		color: "#3B9188",
	},
	balanceAmount: {
		fontSize: 36,
		fontWeight: "bold",
		color: "#00A9FF",
	},
	transactionsContainer: {
		marginBottom: 20,
	},
	transactionsHeading: {
		fontSize: 18,
		fontWeight: "bold",
		color: "#3B9188",
		marginBottom: 10,
	},
	actionButtonsContainer: {
		flexDirection: "row",
		justifyContent: "space-between",
	},
	actionButton: {
		flex: 1,
		height: 50,
		alignItems: "center",
		justifyContent: "center",
		borderRadius: 8,
		marginRight: 10,
	},
	buttonText: {
		color: "#fff",
		fontSize: 16,
		fontWeight: "bold",
	},
});

export default DashboardPage;
