import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Screens from "./screens/index";
import FontAwesome5 from "@expo/vector-icons/FontAwesome5";
import { useState, useEffect, useRef } from "react";
import * as Device from 'expo-device';
import * as Notifications from "expo-notifications";

Notifications.setNotificationHandler({
	handleNotification: async () => ({
		shouldShowAlert: true,
		shouldPlaySound: true,
		shouldSetBadge: true,
	}),
});

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

export default function App() {
	const [expoPushToken, setExpoPushToken] = useState("");
	const [notification, setNotification] = useState(false);
	const notificationListener = useRef();
	const responseListener = useRef();

	useEffect(() => {
		registerForPushNotificationsAsync().then((token) => setExpoPushToken(token));

		notificationListener.current = Notifications.addNotificationReceivedListener((notification) => {
			setNotification(notification);
		});

		responseListener.current = Notifications.addNotificationResponseReceivedListener((response) => {
			console.log(response);
		});

		return () => {
			Notifications.removeNotificationSubscription(notificationListener.current);
			Notifications.removeNotificationSubscription(responseListener.current);
		};
	}, []);

	return (
		<NavigationContainer>
			<Stack.Navigator initialRouteName="Login" screenOptions={{ headerShown: false, statusBarColor: "#DFF5F2", statusBarStyle: "dark", animation: "slide_from_right" }}>
				<Stack.Screen name="Tab" component={TabScreens} />
				<Stack.Screen name="Home" component={Screens.Dashboard} />
				<Stack.Screen name="Entry" component={Screens.ExpenseEntryPage} />
				<Stack.Screen name="Login" component={Screens.LoginScreen} />
				<Stack.Screen name="NotifSettings" component={Screens.NotificationSettings} />
				<Stack.Screen name="Register" component={Screens.RegisterScreen} />
			</Stack.Navigator>
		</NavigationContainer>
	);
}

function TabScreens() {
	return (
		<Tab.Navigator initialRouteName="Dashboard" screenOptions={{ headerShown: false }}>
			<Tab.Screen name="Dashboard" component={Screens.DashboardPage} screenOptions={{ unmountOnBlur: true }} options={{ tabBarIcon: ({ color, size }) => <FontAwesome5 name="home" color={color} size={size} /> }} />
			<Tab.Screen name="Balance" component={Screens.BalanceSummaryScreen} screenOptions={{ unmountOnBlur: true }} options={{ tabBarIcon: ({ color, size }) => <FontAwesome5 name="receipt" color={color} size={size} /> }} />
			<Tab.Screen name="History" component={Screens.ExpenseListScreen} screenOptions={{ unmountOnBlur: true }} options={{ tabBarIcon: ({ color, size }) => <FontAwesome5 name="history" color={color} size={size} /> }} />
			<Tab.Screen name="Notifications" component={Screens.NotificationHistory} screenOptions={{ unmountOnBlur: true }} options={{ tabBarIcon: ({ color, size }) => <FontAwesome5 name="bell" color={color} size={size} /> }} />
		</Tab.Navigator>
	);
}

async function registerForPushNotificationsAsync() {
	let token;

	if (Platform.OS === "android") {
		await Notifications.setNotificationChannelAsync("default", {
			name: "default",
			importance: Notifications.AndroidImportance.MAX,
			vibrationPattern: [0, 250, 250, 250],
			lightColor: "#FF231F7C",
		});
	}

	if (Device.isDevice) {
		const { status: existingStatus } = await Notifications.getPermissionsAsync();
		let finalStatus = existingStatus;
		if (existingStatus !== "granted") {
			const { status } = await Notifications.requestPermissionsAsync();
			finalStatus = status;
		}
		if (finalStatus !== "granted") {
			alert("Failed to get push token for push notification!");
			return;
		}
		token = (await Notifications.getExpoPushTokenAsync()).data;
		console.log(token);
	} else {
		alert("Must use physical device for Push Notifications");
	}

	return token;
}
